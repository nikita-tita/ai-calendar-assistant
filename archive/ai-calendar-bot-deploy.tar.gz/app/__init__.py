"""AI Calendar Assistant - Интеллектуальный календарный ассистент."""

__version__ = "0.1.0"
