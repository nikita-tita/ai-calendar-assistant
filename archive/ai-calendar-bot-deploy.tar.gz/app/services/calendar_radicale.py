"""Radicale CalDAV integration service (local calendar server)."""

from typing import Optional, List
from datetime import datetime, timedelta
import caldav
from caldav.elements import dav
from icalendar import Calendar, Event as ICalEvent
import structlog
import hashlib

from app.config import settings
from app.schemas.events import EventDTO, CalendarEvent, FreeSlot

logger = structlog.get_logger()


class RadicaleService:
    """
    Service for interacting with Radicale CalDAV server.

    Radicale - lightweight open source CalDAV/CardDAV server
    Each user gets their own calendar automatically created by Telegram ID.
    No OAuth required - simple internal calendar management.

    Repository: https://github.com/Kozea/Radicale
    """

    def __init__(self):
        """Initialize Radicale service."""
        self.url = settings.radicale_url

    def _get_user_calendar_name(self, user_id: str) -> str:
        """Generate calendar name for user based on Telegram ID."""
        return f"telegram_{user_id}"

    def _get_user_client(self, user_id: str):
        """
        Create CalDAV client for specific user.

        Args:
            user_id: Telegram user ID

        Returns:
            caldav.DAVClient configured for this user
        """
        # Create client with username = user_id (no password needed with auth=none)
        return caldav.DAVClient(url=self.url, username=str(user_id))

    def _get_user_calendar(self, user_id: str):
        """
        Get or create calendar for user.

        Args:
            user_id: Telegram user ID

        Returns:
            caldav.Calendar object
        """
        try:
            client = self._get_user_client(user_id)
            principal = client.principal()
            calendar_name = self._get_user_calendar_name(user_id)

            # Try to find existing calendar by name
            calendars = principal.calendars()
            for cal in calendars:
                try:
                    # Check display name property
                    cal_props = cal.get_properties([dav.DisplayName()])
                    display_name = cal_props.get('{DAV:}displayname', '')

                    if display_name == calendar_name:
                        logger.info("calendar_found", user_id=user_id, calendar=calendar_name, url=str(cal.url))
                        return cal
                except:
                    # If can't get properties, skip this calendar
                    continue

            # Create new calendar if doesn't exist
            new_calendar = principal.make_calendar(
                name=calendar_name,
                supported_calendar_component_set=['VEVENT']
            )

            logger.info("calendar_created", user_id=user_id, calendar=calendar_name)
            return new_calendar

        except Exception as e:
            logger.error("calendar_error", user_id=user_id, error=str(e), exc_info=True)
            return None

    async def create_event(self, user_id: str, event: EventDTO) -> Optional[str]:
        """
        Create calendar event in user's personal calendar.

        Args:
            user_id: Telegram user ID
            event: Event details

        Returns:
            Event UID or None if failed
        """
        try:
            calendar = self._get_user_calendar(user_id)
            if not calendar:
                return None

            # Calculate end time
            end_time = event.end_time or (
                event.start_time + timedelta(minutes=event.duration_minutes or 60)
            )

            # Create iCalendar event
            cal = Calendar()
            cal.add('prodid', '-//AI Calendar Assistant//Telegram Bot//RU')
            cal.add('version', '2.0')

            ical_event = ICalEvent()

            # Generate unique UID with timestamp to avoid collisions
            import time
            uid = hashlib.md5(
                f"{user_id}_{event.title}_{event.start_time.isoformat()}_{time.time_ns()}".encode()
            ).hexdigest()

            ical_event.add('uid', uid)
            ical_event.add('summary', event.title or "Событие")
            ical_event.add('dtstart', event.start_time)
            ical_event.add('dtend', end_time)
            ical_event.add('dtstamp', datetime.now())

            if event.description:
                ical_event.add('description', event.description)

            if event.location:
                ical_event.add('location', event.location)

            # Add attendees if any
            if event.attendees:
                for attendee in event.attendees:
                    ical_event.add('attendee', f'mailto:{attendee}')

            cal.add_component(ical_event)

            # Save to Radicale
            calendar.save_event(cal.to_ical().decode('utf-8'))

            logger.info(
                "event_created",
                user_id=user_id,
                uid=uid,
                title=event.title
            )

            return uid

        except Exception as e:
            logger.error("event_create_error", user_id=user_id, error=str(e), exc_info=True)
            return None

    async def list_events(
        self,
        user_id: str,
        time_min: datetime,
        time_max: datetime
    ) -> List[CalendarEvent]:
        """
        List events from user's calendar in time range.

        Args:
            user_id: Telegram user ID
            time_min: Start of time range
            time_max: End of time range

        Returns:
            List of calendar events
        """
        try:
            calendar = self._get_user_calendar(user_id)
            if not calendar:
                return []

            # Search events in time range
            events = calendar.date_search(start=time_min, end=time_max)

            calendar_events = []
            for event in events:
                ical = Calendar.from_ical(event.data)

                for component in ical.walk('VEVENT'):
                    start = component.get('dtstart').dt
                    end = component.get('dtend').dt

                    # Convert to datetime if date object
                    if not isinstance(start, datetime):
                        start = datetime.combine(start, datetime.min.time())
                    if not isinstance(end, datetime):
                        end = datetime.combine(end, datetime.min.time())

                    calendar_events.append(CalendarEvent(
                        id=str(component.get('uid')),
                        summary=str(component.get('summary', 'Событие')),
                        description=str(component.get('description', '')),
                        start=start,
                        end=end,
                        location=str(component.get('location', '')),
                        attendees=[
                            str(att).replace('mailto:', '')
                            for att in component.get('attendee', [])
                        ],
                        html_link=f"{self.url}/{self._get_user_calendar_name(user_id)}/{component.get('uid')}.ics"
                    ))

            logger.info("events_listed", user_id=user_id, count=len(calendar_events))
            return calendar_events

        except Exception as e:
            logger.error("events_list_error", user_id=user_id, error=str(e), exc_info=True)
            return []

    async def find_free_slots(
        self,
        user_id: str,
        date: datetime,
        work_hours_start: int = 9,
        work_hours_end: int = 18,
        slot_duration: int = 60
    ) -> List[FreeSlot]:
        """
        Find free time slots on a given date.

        Args:
            user_id: Telegram user ID
            date: Date to check
            work_hours_start: Start of work day (hour)
            work_hours_end: End of work day (hour)
            slot_duration: Slot duration in minutes

        Returns:
            List of free time slots
        """
        try:
            # Get all events for the day
            day_start = date.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day_start + timedelta(days=1)

            events = await self.list_events(user_id, day_start, day_end)

            # Create list of busy time ranges
            busy_ranges = []
            for event in events:
                busy_ranges.append((event.start, event.end))

            # Sort by start time
            busy_ranges.sort(key=lambda x: x[0])

            # Generate free slots
            free_slots = []
            current_time = date.replace(hour=work_hours_start, minute=0, second=0, microsecond=0)
            end_of_day = date.replace(hour=work_hours_end, minute=0, second=0, microsecond=0)

            while current_time < end_of_day:
                slot_end = current_time + timedelta(minutes=slot_duration)

                # Check if slot overlaps with any busy range
                is_free = True
                for busy_start, busy_end in busy_ranges:
                    if (current_time < busy_end and slot_end > busy_start):
                        is_free = False
                        # Jump to end of busy period
                        current_time = busy_end
                        break

                if is_free:
                    free_slots.append(FreeSlot(
                        start=current_time,
                        end=slot_end,
                        duration_minutes=slot_duration
                    ))
                    current_time = slot_end

            logger.info("free_slots_found", user_id=user_id, count=len(free_slots))
            return free_slots

        except Exception as e:
            logger.error("free_slots_error", user_id=user_id, error=str(e), exc_info=True)
            return []

    async def update_event(self, user_id: str, event_uid: str, updated_event: EventDTO) -> bool:
        """
        Update existing event in user's calendar.

        Args:
            user_id: Telegram user ID
            event_uid: Event UID to update
            updated_event: New event details

        Returns:
            True if successful, False otherwise
        """
        try:
            calendar = self._get_user_calendar(user_id)
            if not calendar:
                return False

            # Find event to update
            events = calendar.events()
            for event in events:
                ical = Calendar.from_ical(event.data)
                for component in ical.walk('VEVENT'):
                    if str(component.get('uid')) == event_uid:
                        # Update fields if provided
                        if updated_event.title:
                            component['summary'] = updated_event.title
                        if updated_event.start_time:
                            component['dtstart'].dt = updated_event.start_time
                        if updated_event.end_time:
                            component['dtend'].dt = updated_event.end_time
                        elif updated_event.start_time and updated_event.duration_minutes:
                            component['dtend'].dt = updated_event.start_time + timedelta(minutes=updated_event.duration_minutes)
                        if updated_event.location:
                            component['location'] = updated_event.location
                        if updated_event.description:
                            component['description'] = updated_event.description

                        # Save updated event
                        event.data = ical.to_ical()
                        event.save()

                        logger.info("event_updated", user_id=user_id, uid=event_uid, title=updated_event.title)
                        return True

            logger.warning("event_not_found_for_update", user_id=user_id, uid=event_uid)
            return False

        except Exception as e:
            logger.error("event_update_error", user_id=user_id, error=str(e), exc_info=True)
            return False

    async def delete_event(self, user_id: str, event_uid: str) -> bool:
        """
        Delete event from user's calendar.

        Args:
            user_id: Telegram user ID
            event_uid: Event UID

        Returns:
            True if successful, False otherwise
        """
        try:
            calendar = self._get_user_calendar(user_id)
            if not calendar:
                return False

            # Find and delete event
            events = calendar.events()
            for event in events:
                ical = Calendar.from_ical(event.data)
                for component in ical.walk('VEVENT'):
                    if str(component.get('uid')) == event_uid:
                        event.delete()
                        logger.info("event_deleted", user_id=user_id, uid=event_uid)
                        return True

            logger.warning("event_not_found", user_id=user_id, uid=event_uid)
            return False

        except Exception as e:
            logger.error("event_delete_error", user_id=user_id, error=str(e), exc_info=True)
            return False

    def is_connected(self) -> bool:
        """Check if Radicale server is accessible."""
        try:
            # Test with a dummy user ID
            client = caldav.DAVClient(url=self.url, username="test")
            client.principal()
            return True
        except Exception as e:
            logger.error("radicale_connection_error", error=str(e))
            return False


# Global instance
calendar_service = RadicaleService()
