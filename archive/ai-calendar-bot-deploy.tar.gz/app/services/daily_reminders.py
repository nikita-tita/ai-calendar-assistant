"""Daily reminders service for morning and evening messages."""

import asyncio
from datetime import datetime, time
from typing import Dict
import structlog
from telegram import Bot
from telegram.error import TelegramError

from app.config import settings
from app.services.calendar_radicale import calendar_service
from app.utils.datetime_parser import format_datetime_human

logger = structlog.get_logger()


class DailyRemindersService:
    """Service for sending daily reminders to users."""

    def __init__(self, bot: Bot):
        """Initialize reminders service."""
        self.bot = bot
        self.active_users: Dict[str, int] = {}  # user_id -> chat_id mapping
        self.running = False

    def register_user(self, user_id: str, chat_id: int):
        """Register user for daily reminders."""
        self.active_users[user_id] = chat_id
        logger.info("user_registered_for_reminders", user_id=user_id)

    async def send_morning_reminder(self, user_id: str, chat_id: int):
        """Send morning reminder with today's events."""
        try:
            # Get today's events
            events = await calendar_service.list_events(user_id)
            today = datetime.now().date()
            today_events = [
                e for e in events
                if e['start'].date() == today
            ]

            if not today_events:
                message = """☀️ Доброе утро!

📅 На сегодня событий не запланировано.
Отличный день, чтобы всё успеть!"""
            else:
                events_list = "\n".join([
                    f"• {e['start'].strftime('%H:%M')} - {e['title']}"
                    for e in sorted(today_events, key=lambda x: x['start'])
                ])
                message = f"""☀️ Доброе утро!

📅 Ваши события на сегодня:

{events_list}

Успешного дня! 💼"""

            await self.bot.send_message(chat_id=chat_id, text=message)
            logger.info("morning_reminder_sent", user_id=user_id)

        except TelegramError as e:
            logger.error("morning_reminder_failed", user_id=user_id, error=str(e))
        except Exception as e:
            logger.error("morning_reminder_error", user_id=user_id, error=str(e))

    async def send_evening_reminder(self, user_id: str, chat_id: int):
        """Send evening motivational message."""
        try:
            # Get today's completed events count
            events = await calendar_service.list_events(user_id)
            today = datetime.now().date()
            today_events = [
                e for e in events
                if e['start'].date() == today
            ]

            motivational_messages = [
                "🌟 Отличная работа сегодня! Ты молодец, столько всего успел. Завтра будет ещё продуктивнее!",
                "🎯 Сегодня был насыщенный день! Ты делаешь большие шаги к своим целям. Продолжай в том же духе!",
                "💪 Ещё один успешный день позади! Твоя целеустремлённость впечатляет. Дальше — больше!",
                "✨ Ты снова показал отличные результаты! Каждый день приближает тебя к успеху. Так держать!",
                "🚀 Сегодня ты был на высоте! Твой прогресс заметен. Завтра покорим новые вершины!",
            ]

            # Rotate message based on day of year
            message_index = datetime.now().timetuple().tm_yday % len(motivational_messages)
            base_message = motivational_messages[message_index]

            if today_events:
                stats = f"\n\n📊 Сегодня у тебя было {len(today_events)} событий"
                message = base_message + stats
            else:
                message = base_message

            message += "\n\n😴 Отдохни и набирайся сил для новых свершений!"

            await self.bot.send_message(chat_id=chat_id, text=message)
            logger.info("evening_reminder_sent", user_id=user_id)

        except TelegramError as e:
            logger.error("evening_reminder_failed", user_id=user_id, error=str(e))
        except Exception as e:
            logger.error("evening_reminder_error", user_id=user_id, error=str(e))

    async def run_daily_schedule(self):
        """Run daily reminder schedule."""
        self.running = True
        logger.info("daily_reminders_started")

        while self.running:
            try:
                now = datetime.now()
                current_time = now.time()

                # Morning reminder at 9:00
                if time(9, 0) <= current_time < time(9, 1):
                    for user_id, chat_id in list(self.active_users.items()):
                        await self.send_morning_reminder(user_id, chat_id)
                        await asyncio.sleep(1)  # Rate limiting

                # Evening reminder at 20:00
                elif time(20, 0) <= current_time < time(20, 1):
                    for user_id, chat_id in list(self.active_users.items()):
                        await self.send_evening_reminder(user_id, chat_id)
                        await asyncio.sleep(1)  # Rate limiting

                # Check every minute
                await asyncio.sleep(60)

            except Exception as e:
                logger.error("daily_schedule_error", error=str(e))
                await asyncio.sleep(60)

    def stop(self):
        """Stop daily reminders."""
        self.running = False
        logger.info("daily_reminders_stopped")


# Global instance (will be initialized in main app)
reminders_service: DailyRemindersService = None
